package com.example.pedrosilva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjPedroSilvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjPedroSilvaApplication.class, args);
	}

}
