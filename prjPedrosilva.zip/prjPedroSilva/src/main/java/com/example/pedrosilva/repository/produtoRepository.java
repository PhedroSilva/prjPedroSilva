package com.example.pedrosilva.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

	import com.example.pedrosilva.entities.produto;

	public interface produtoRepository extends JpaRepository<produto, Long> {

	}