package com.example.pedrosilva.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.pedrosilva.entities.itempedido;
	import com.example.pedrosilva.repository.itempedidoRepository;
		 
		@Service
		public class itempedidoService {

			@Autowired
			private itempedidoRepository itempedidoRepository;

			public List<itempedido> getAllItempedido() {
				return itempedidoRepository.findAll();
			}

			public itempedido getitempedidoById(long funcodigo) {
				return itempedidoRepository.findById(funcodigo).orElse(null);
			}

			public itempedido saveItempedido(itempedido itempedido) {
				return itempedidoRepository.save(itempedido);
			}

		}
