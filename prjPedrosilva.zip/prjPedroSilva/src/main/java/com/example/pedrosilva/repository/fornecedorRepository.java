package com.example.pedrosilva.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

	import com.example.pedrosilva.entities.fornecedor;

	public interface fornecedorRepository extends JpaRepository<fornecedor, Long> {

	}
