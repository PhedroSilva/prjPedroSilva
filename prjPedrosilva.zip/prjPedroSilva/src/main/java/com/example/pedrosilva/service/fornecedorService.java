package com.example.pedrosilva.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.pedrosilva.entities.cliente;
	import com.example.pedrosilva.repository.clienteRepository;
	import com.example.pedrosilva.repository.fornecedorRepository;
	import com.example.pedrosilva.entities.fornecedor;

	 
		@Service
		public class fornecedorService {

			@Autowired
			private fornecedorRepository fornecedorRepository;

			public List<fornecedor> getAllFornecedor() {
				return fornecedorRepository.findAll();
			}

			public fornecedor getFornecedorById(long funcodigo) {
				return fornecedorRepository.findById(funcodigo).orElse(null);
			}

			public fornecedor saveFornecedor(fornecedor fornecedor) {
				return fornecedorRepository.save(fornecedor);
			}

		}
