package com.example.pedrosilva.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.pedrosilva.entities.produto;
	import com.example.pedrosilva.repository.produtoRepository;
		 
		@Service
		public class produtoService {

			@Autowired
			private produtoRepository produtoRepository;

			public List<produto> getAllProduto() {
				return produtoRepository.findAll();
			}

			public produto getProdutoById(long funcodigo) {
				return produtoRepository.findById(funcodigo).orElse(null);
			}

			public produto saveProduto(produto produto) {
				return produtoRepository.save(produto);
			}

		}
