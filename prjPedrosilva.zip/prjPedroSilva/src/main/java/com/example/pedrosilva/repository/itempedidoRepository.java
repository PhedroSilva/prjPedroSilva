package com.example.pedrosilva.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

	import com.example.pedrosilva.entities.itempedido;

	public interface itempedidoRepository extends JpaRepository<itempedido, Long> {

	}
