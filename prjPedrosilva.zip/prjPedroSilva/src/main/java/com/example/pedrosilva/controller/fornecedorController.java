package com.example.pedrosilva.controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.pedrosilva.entities.cliente;
	import com.example.pedrosilva.entities.fornecedor;
	import com.example.pedrosilva.service.clienteService;

	@RestController
		@RequestMapping("/fornecedor")
		public class fornecedorController {

			private final fornecedorService fornecedorService;

			@Autowired
			public fornecedorController(fornecedorService fornecedorService) {
				this.fornecedorService = fornecedorService;
			}

			@GetMapping("/{id}")
			public ResponseEntity<fornecedor> findFornecedorbyId(@PathVariable Long id) {
				fornecedor fornecedor = fornecedorService.getfornecedorById(id);
				if (fornecedor != null) {
					return ResponseEntity.ok(fornecedor);
				} else {
					return ResponseEntity.notFound().build();
				}
			}

			@GetMapping("/")
			public ResponseEntity<List<fornecedor>> findAllUsuarioscontrol() {
				List<fornecedor> fornecedor = fornecedorService.getAllFornecedor();
				return ResponseEntity.ok(fornecedor);
			}

			@PostMapping("/")
			public ResponseEntity<fornecedor> insertUsuariosControl(@RequestBody fornecedor fornecedor) {
				fornecedor novofornecedor = fornecedorService.saveFornecedor(fornecedor);
				return ResponseEntity.status(HttpStatus.CREATED).body(novofornecedor);
			}

		}
