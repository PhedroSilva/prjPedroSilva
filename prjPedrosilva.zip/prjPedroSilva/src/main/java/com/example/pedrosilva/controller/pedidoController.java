package com.example.pedrosilva.controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.pedrosilva.entities.pedido;
	import com.example.pedrosilva.service.pedidoService;

	@RestController
		@RequestMapping("/pedido")
		public class pedidoController {

			private final pedidoService pedidoService;

			@Autowired
			public pedidoController(pedidoService pedidoService) {
				this.pedidoService = pedidoService;
			}

			@GetMapping("/{id}")
			public ResponseEntity<pedido> findpedidobyId(@PathVariable Long id) {
				pedido pedido = pedidoService.getPedidoById(id);
				if (pedido != null) {
					return ResponseEntity.ok(pedido);
				} else {
					return ResponseEntity.notFound().build();
				}
			}

			@GetMapping("/")
			public ResponseEntity<List<pedido>> findAllUsuarioscontrol() {
				List<pedido> pedido = pedidoService.getAllPedido();
				return ResponseEntity.ok(pedido);
			}

			@PostMapping("/")
			public ResponseEntity<pedido> insertUsuariosControl(@RequestBody pedido pedido) {
				pedido pedido1 = pedidoService.savePedido(pedido);
				return ResponseEntity.status(HttpStatus.CREATED).body(novopedido);
			}

		}
