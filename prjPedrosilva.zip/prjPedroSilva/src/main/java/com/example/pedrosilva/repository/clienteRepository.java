package com.example.pedrosilva.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

	import com.example.pedrosilva.entities.cliente;

	public interface clienteRepository extends JpaRepository<cliente, Long> {

	}
