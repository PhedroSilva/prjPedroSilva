package com.example.pedrosilva.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.pedrosilva.entities.pedido;
	import com.example.pedrosilva.repository.pedidoRepository;
		 
		@Service
		public class pedidoService {

			@Autowired
			private pedidoRepository pedidoRepository;

			public List<pedido> getAllPedido() {
				return pedidoRepository.findAll();
			}

			public pedido getPedidoById(long funcodigo) {
				return pedidoRepository.findById(funcodigo).orElse(null);
			}

			public pedido savePedido(pedido pedido) {
				return pedidoRepository.save(pedido);
			}

		}
