package com.example.pedrosilva.controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.pedrosilva.entities.itempedido;
	import com.example.pedrosilva.service.itempedidoService;

	@RestController
		@RequestMapping("/itempedido")
		public class itempedidoController {

			private final itempedidoService itempedidoService;

			@Autowired
			public itempedidoController(itempedidoService itempedidoService) {
				this.itempedidoService = itempedidoService;
			}

			@GetMapping("/{id}")
			public ResponseEntity<itempedido> findItempedidobyId(@PathVariable Long id) {
				itempedido itempedido = itempedidoService.getitempedidoById(id);
				if (itempedido != null) {
					return ResponseEntity.ok(itempedido);
				} else {
					return ResponseEntity.notFound().build();
				}
			}

			@GetMapping("/")
			public ResponseEntity<List<itempedido>> findAllUsuarioscontrol() {
				List<itempedido> itempedido = itempedidoService.getAllItempedido();
				return ResponseEntity.ok(itempedido);
			}

			@PostMapping("/")
			public ResponseEntity<itempedido> insertUsuariosControl(@RequestBody itempedido itempedido) {
				itempedido novoitempedido = itempedidoService.saveItempedido(itempedido);
				return ResponseEntity.status(HttpStatus.CREATED).body(novoitempedido);
			}

		}
