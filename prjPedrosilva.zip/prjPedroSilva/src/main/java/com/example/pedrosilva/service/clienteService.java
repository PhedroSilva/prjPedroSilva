package com.example.pedrosilva.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	
	import com.example.pedrosilva.repository.clienteRepository;
	import com.example.pedrosilva.entities.cliente;
		 
		@Service
		public class clienteService {

			@Autowired
			private clienteRepository clienteRepository;

			public List<cliente> getAllCliente() {
				return clienteRepository.findAll();
			}

			public cliente getClienteById(long funcodigo) {
				return clienteRepository.findById(funcodigo).orElse(null);
			}

			public cliente saveCliente(cliente cliente) {
				return clienteRepository.save(cliente);
			}

		}
	
