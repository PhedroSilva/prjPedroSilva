package com.example.pedrosilva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjPedroSilvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
